﻿namespace CustomerApp.Navigation;

public enum AppPage
{

}
